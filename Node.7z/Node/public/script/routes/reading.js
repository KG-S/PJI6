

export function favoriteReading(bookData, idUser) {
    fetch("http://localhost:8080/api/v1/reading/favorite", {
        method: "PUT",
        body: JSON.stringify(bookData),
        headers: {
            "Content-Type": "application/json",
        },
    }, idUser)
    .then((response) =>  {
        console.log("Book created successfully:", response);
    })
    .catch((error) => {
        console.error("Error creating book:", error);
    });
}