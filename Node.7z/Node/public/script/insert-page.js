import { containerError, containerList } from "./components-page.js";
import { createBook } from "./routes/book.js";
import { favoriteReading } from "./routes/reading.js";

export function insertOnPage({title, author, publisher, publishedDate, pagesNumber, categories, imageLink, previewLink}) {
    const cardBook = $("<li>");
    cardBook.addClass("card");
    cardBook.html(`
        <img src="${imageLink}" class="card-img-top" onerror="this.src='/media/error-image';" alt="book image">
        <div class="card-body align-self-center" tabindex="0">
            <h5 class="card-title" aria-label="book title ${title}">${title}</h5>
            <p class="card-text"><em class="card__text__title">Author:</em> ${author}</p>
            <p class="card-text"><em class="card__text__title">Publisher:</em> ${publisher}</p>
            <p class="card-text"><em class="card__text__title">Published:</em> ${publishedDate}</p>
            <p class="card-text"><em class="card__text__title">Pages:</em> ${pagesNumber}</p>
            <p class="card-text"><em class="card__text__title">Category:</em> ${categories}</p>
            <a href="${previewLink}" class="btn link" aria-label="preview link in Google Books" tabindex="0">Sala</a>
            <button class="btn create-book-btn" title="${title}" pages="${pagesNumber}" gender="imagine" 
            author="${author}" classification="1" summary="imagine" dataAdd="${publishedDate}"  
             bookState="AUTENTICADO" average="5">
            Favoritar</button>
        </div>
        `);
    containerList.append(cardBook);


    var id = localStorage.getItem("idUser");

    cardBook.find(".create-book-btn").click(function () {
        const button = $(this);
        const bookData = {
            title: button.attr("title"),
            pages: button.attr("pages"),
            gender: button.attr("gender"),
            author: button.attr("author"),
            classification: button.attr("classification"),
            summary: button.attr("summary"),
            dataAdd: button.attr("dataAdd"),
            idUserAdd: id,
            bookState: button.attr("bookState"),
            average: button.attr("average")
        };
        console.log(JSON.stringify(bookData))
        console.log(id)
        createBook(bookData);
        favoriteReading(bookData, id)
        /* mudar para o seguinte:
        favoriteReading(BookData, idUser) //guardar o idUser globalmente pra poder usá-lo;
        essa função vai no controller do Reading chamar o addNewBook do BookCRUD
        addNewBook vai retornar um livro
        esse livro vai ser passado como parametro no createReading (se já existir 
            o reading, retorna o reading já existente)
        esse reading retornando vai pra favoriteReading
        onde esse reading é setado no DB como favoritado ou não favoritado */
    });
}

export function errorOnPage(errorMessage) {
    containerError.html("");
    const errorText = $("<p>");
    errorText.html(errorMessage);
    containerError.show();
    containerError.append(errorText);
}